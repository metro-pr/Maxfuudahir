'use strict'

const fs = require('fs')
const path = require('path')

const DATA_PATH = path.join(__dirname, 'auth_cache.json')

function ensureStore() {
    if (!fs.existsSync(DATA_PATH)) {
        fs.writeFileSync(DATA_PATH, '[]', 'utf8')
    }
}

function loadEntries() {
    ensureStore()

    try {
        const parsed = JSON.parse(fs.readFileSync(DATA_PATH, 'utf8'))
        return Array.isArray(parsed) ? parsed : []
    } catch (error) {
        throw new Error(`Failed to read auth_cache.json: ${error.message}`)
    }
}

function saveEntries(entries) {
    ensureStore()
    fs.writeFileSync(DATA_PATH, JSON.stringify(entries, null, 2), 'utf8')
}

function matches(entry, discordId, cacheName) {
    return entry.discordId === discordId && entry.cacheName === cacheName
}

async function getAuthCacheEntry(discordId, cacheName) {
    return loadEntries().find((entry) => matches(entry, discordId, cacheName)) || null
}

async function setAuthCacheEntry(discordId, cacheName, data) {
    const entries = loadEntries()
    const record = {
        discordId,
        cacheName,
        data,
        updatedAt: new Date().toISOString()
    }
    const index = entries.findIndex((entry) => matches(entry, discordId, cacheName))

    if (index === -1) entries.push(record)
    else entries[index] = record

    saveEntries(entries)
    return record
}

async function deleteAuthCacheEntry(discordId, cacheName) {
    const entries = loadEntries()
    const index = entries.findIndex((entry) => matches(entry, discordId, cacheName))
    if (index === -1) return null

    const [removed] = entries.splice(index, 1)
    saveEntries(entries)
    return removed
}

async function deleteAuthCacheForUser(discordId) {
    const entries = loadEntries()
    const remaining = entries.filter((entry) => entry.discordId !== discordId)
    const deletedCount = entries.length - remaining.length

    if (deletedCount > 0) saveEntries(remaining)

    return { deletedCount }
}

module.exports = {
    getAuthCacheEntry,
    setAuthCacheEntry,
    deleteAuthCacheEntry,
    deleteAuthCacheForUser
}