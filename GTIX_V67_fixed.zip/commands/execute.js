'use strict'

const { SlashCommandBuilder, ApplicationIntegrationType, InteractionContextType } = require('discord.js')
const { XboxAccount } = require('../stuff/api/xbox/xbox')
const { RealmAPI } = require('../stuff/api/realm/realm')
const { getAccountByDiscordId } = require('../database/models/account')
const { isValidRealmCode, isValidRealmId } = require('../stuff/utils/validation')
const { blockIfWhitelisted } = require('../stuff/utils/whitelistGuard')
const {
    successContainer,
    errorContainer,
    infoContainer,
    loadingContainer,
    progressContainer,
    ComponentsV2Flags
} = require('../stuff/utils/containers')
const logger = require('../stuff/utils/logger')

const createInstance = require('../stuff/bedrockx/helpers/createInstance')

const activeJobs = global.__executeActiveJobs || (global.__executeActiveJobs = new Map())

const LOOP_DELAY_MS = 12_500

function microsoftLinkUrl(code) {
    return `https://www.microsoft.com/link?otc=${encodeURIComponent(code)}`
}

function cancellableDelay(ms, job) {
    return new Promise((resolve) => {
        if (job.cancelled) return resolve()
        const t = setTimeout(() => {
            job.onCancel = null
            resolve()
        }, ms)
        job.onCancel = () => {
            clearTimeout(t)
            resolve()
        }
    })
}

module.exports = {
    activeJobs,

    data: new SlashCommandBuilder()
        .setName('impact')
        .setDescription('Run repeated impact tests on a Realm')
        .setIntegrationTypes([ApplicationIntegrationType.GuildInstall, ApplicationIntegrationType.UserInstall])
        .setContexts([InteractionContextType.Guild, InteractionContextType.BotDM, InteractionContextType.PrivateChannel])
        .addStringOption((option) => option
            .setName('code')
            .setDescription('Realm code or Realm ID')
            .setRequired(true))
        .addIntegerOption((option) => option
            .setName('loops')
            .setDescription('How many test cycles to run, from 5 to 100')
            .setRequired(true)
            .setMinValue(5)
            .setMaxValue(100)),

    async execute(interaction) {
        const userId = interaction.user.id

        if (activeJobs.has(userId)) {
            await interaction.reply({
                components: [errorContainer('Impact is already running', 'Another impact task is active. Use /abort if you want to stop it.')],
                flags: ComponentsV2Flags,
                ephemeral: true
            })
            return
        }

        await interaction.deferReply()
        await interaction.editReply({
            components: [loadingContainer('Getting the test ready', 'Checking the Realm before the impact starts…')],
            flags: ComponentsV2Flags
        })

        const destination = interaction.options.getString('code').trim()
        const loops = interaction.options.getInteger('loops') || 1

        const isId = isValidRealmId(destination)
        const isCode = isValidRealmCode(destination)

        if (isId && await blockIfWhitelisted(interaction, destination)) return

        if (!isId && !isCode) {
            await interaction.editReply({
                components: [errorContainer('Bad Realm value', 'Please enter a valid Realm code or numeric Realm ID.')],
                flags: ComponentsV2Flags
            })
            return
        }

        const linkedAccount = await getAccountByDiscordId(userId)
        if (!linkedAccount) {
            await interaction.editReply({
                components: [errorContainer('Microsoft account needed', 'Run /account-link first so I can reach the Realm.')],
                flags: ComponentsV2Flags
            })
            return
        }

        let authPromptSent = false
        const account = new XboxAccount(userId, async (data) => {
            if (authPromptSent) return
            authPromptSent = true

            await interaction.editReply({
                components: [infoContainer(
                    'Sign-in needed',
                    `Open Microsoft, then enter code **${data.user_code}**.`,
                    { label: 'Open sign-in page', url: microsoftLinkUrl(data.user_code) }
                )],
                flags: ComponentsV2Flags
            }).catch((error) => {
                logger.warn?.(`[/impact] Microsoft sign-in prompt failed: ${error?.message ?? error}`)
            })
        })

        let realm
        try {
            const realmApi = new RealmAPI(account)
            await realmApi.init()

            realm = isId
                ? await realmApi.getRealmById(destination)
                : await realmApi.getRealmByCode(destination)

            if (!realm) {
                await interaction.editReply({
                    components: [errorContainer('Invalid destination', isId
                        ? 'No Realm was found for the provided ID.'
                        : 'No Realm was found for the provided code.')],
                    flags: ComponentsV2Flags
                })
                return
            }

            if (await blockIfWhitelisted(interaction, realm.id)) return

            delete realm.players
        } catch (error) {
            const reason = String(error?.message || '').trim()
            const isAccessDenied = /banned from this realm|don't have access to this realm|not invited|removed from it/i.test(reason)
            const title = isAccessDenied ? 'Realm access blocked' : 'Could not find Realm'
            const message = reason || 'I could not read that Realm. Please try again.'

            logger.error(`[/impact] Lookup failed for ${userId}: ${message}`)
            await interaction.editReply({
                components: [errorContainer(title, message)],
                flags: ComponentsV2Flags
            })
            return
        }

        const INTERACTION_TOKEN_TTL_MS = 14 * 60 * 1000
        const interactionStart = interaction.createdTimestamp
        let fallbackMessage = null

        const safeEdit = async (payload) => {
            const tokenExpired = (Date.now() - interactionStart) >= INTERACTION_TOKEN_TTL_MS

            if (!tokenExpired && !fallbackMessage) {
                try {
                    await interaction.editReply(payload)
                    return
                } catch (err) {
                    logger.warn?.(`[/impact] editReply failed: ${err?.message ?? err}`)
                }
            }

            if (!fallbackMessage) {
                fallbackMessage = await interaction.channel.send(payload).catch(() => null)
            } else {
                await fallbackMessage.edit(payload).catch(() => {})
            }
        }

        let completedLoops = 0

        const job = {
            userId,
            cancelled: false,
            onCancel: null,
            cancel() {
                this.cancelled = true
                try { this.onCancel?.() } catch {}
            }
        }
        activeJobs.set(userId, job)

        try {
            const realmApi = new RealmAPI(account)
            await realmApi.init().catch(() => {})

            for (let i = 0; i < loops; i++) {
                if (job.cancelled) break

                await safeEdit({
                    components: [progressContainer(
                        'Impact test running',
                        `Realm: **${realm.name}**\n\nPreparing cycle **${i + 1} of ${loops}**.\n\nCompleted cycles: **${completedLoops} / ${loops}**`,
                        i,
                        loops
                    )],
                    flags: ComponentsV2Flags
                })

                let host
                try {
                    host = await realmApi.getConnectionInfo(realm.id)
                } catch (error) {
                    await safeEdit({
                        components: [errorContainer(
                            'Test step skipped',
                            `I could not get connection details for **${realm.name}** on test ${i + 1}.\n\n${error.message || 'Please try again.'}`
                        )],
                        flags: ComponentsV2Flags
                    })
                    if (i < loops - 1) await cancellableDelay(LOOP_DELAY_MS, job)
                    continue
                }

                if (host?.networkProtocol !== 'NETHERNET_JSONRPC') {
                    await safeEdit({
                        components: [errorContainer('Test cannot continue', `**${realm.name}** uses \`${host?.networkProtocol}\`, which this test does not support.`)],
                        flags: ComponentsV2Flags
                    })
                    break
                }

                await safeEdit({
                    components: [progressContainer(
                        'Impact test running',
                        `Realm: **${realm.name}**\n\nConnection details verified. Running cycle **${i + 1} of ${loops}**.\n\nCompleted cycles: **${completedLoops} / ${loops}**`,
                        i,
                        loops
                    )],
                    flags: ComponentsV2Flags
                })

                try {
                    await createInstance(realm, account, {
                        protocol: host.networkProtocol,
                        address: host.address,
                        external: { enabled: true, type: 3 }
                    })
                    completedLoops++
                } catch (error) {
                    logger.error(`[/impact] createInstance failure for ${userId}: ${error.message}`)
                }

                if (job.cancelled) break

                if (i < loops - 1) {
                    await safeEdit({
                        components: [progressContainer(
                            'Next impact test',
                            `**${realm.name}** completed cycle **${i + 1} of ${loops}**.\n\nPreparing cycle **${i + 2} of ${loops}**…\n\nCompleted cycles: **${completedLoops} / ${loops}**`,
                            i + 1,
                            loops
                        )],
                        flags: ComponentsV2Flags
                    })
                    await cancellableDelay(LOOP_DELAY_MS, job)
                }
            }

            if (job.cancelled) {
                await safeEdit({
                    components: [infoContainer(
                        'Impact stopped',
                        `**${realm.name}**\n\n` +
                        `\`${'▓'.repeat(Math.round((completedLoops / loops) * 18))}${'░'.repeat(18 - Math.round((completedLoops / loops) * 18))}\` **${Math.round((completedLoops / loops) * 100)}%**\n\n` +
                        `Stopped after **${completedLoops} of ${loops}** successful test(s).`
                    )],
                    flags: ComponentsV2Flags
                })
            } else {
                await safeEdit({
                    components: [successContainer(
                        'Impact tests finished',
                        `**${realm.name}**\n\n\`${'▓'.repeat(18)}\` **100%**\n\nFinished **${completedLoops} of ${loops}** tests successfully.`
                    )],
                    flags: ComponentsV2Flags
                })
            }
        } catch (error) {
            logger.error(`[/impact] Loop error for ${userId}: ${error.message}`)
            await safeEdit({
                components: [errorContainer('Impact stopped with an error', 'The test could not finish. Please try again with fewer cycles.')],
                flags: ComponentsV2Flags
            }).catch(() => {})
        } finally {
            activeJobs.delete(userId)
        }
    }
}
