const { SlashCommandBuilder, MessageFlags, ApplicationIntegrationType, InteractionContextType } = require('discord.js')
const { XboxAccount, clearAuthCacheForUser } = require('../stuff/api/xbox/xbox')
const { getAccountByDiscordId, getAccountByXuid, linkAccount, unlinkAccount } = require('../database/models/account')
const { disconnectAllForUser } = require('../stuff/bedrockx/index')
const { successContainer, errorContainer, infoContainer, ComponentsV2Flags } = require('../stuff/utils/containers')
const logger = require('../stuff/utils/logger')

function microsoftLinkUrl(code) {
    return `https://www.microsoft.com/link?otc=${encodeURIComponent(code)}`
}

async function link(interaction) {
    await interaction.deferReply({ flags: MessageFlags.Ephemeral })

    const existing = await getAccountByDiscordId(interaction.user.id)
    if (existing) {
        await interaction.editReply({
            components: [errorContainer('Already connected', `Microsoft account **${existing.gamertag}** is already linked here. Use /account-unlink before adding another one.`)],
            flags: ComponentsV2Flags
        })
        return
    }

    let codeSent = false

    const account = new XboxAccount(interaction.user.id, async (data) => {
        if (codeSent) return
        codeSent = true

        await interaction.editReply({
            components: [infoContainer(
                'Microsoft sign-in',
                `Open the Microsoft page, then enter this code: **${data.user_code}**.`,
                { label: 'Open Microsoft page', url: microsoftLinkUrl(data.user_code) }
            )],
            flags: ComponentsV2Flags
        })
    })

    try {
        const profile = await account.getProfile()

        if (!profile.xuid) {
            logger.error(`Link failed for ${interaction.user.id}: no XUID returned from Xbox profile`)

            await interaction.editReply({
                components: [errorContainer('Could not link account', 'Microsoft did not finish the sign-in. Please run /account-link again.')],
                flags: ComponentsV2Flags
            })
            return
        }

        const conflict = await getAccountByXuid(profile.xuid)
        if (conflict && conflict.discordId !== interaction.user.id) {
            await interaction.editReply({
                components: [errorContainer('Account already used', 'That Microsoft account is already connected to another Discord user.')],
                flags: ComponentsV2Flags
            })
            return
        }

        await linkAccount(interaction.user.id, profile.xuid, profile.gamertag)

        await interaction.editReply({
            components: [successContainer('Account connected', `You are now using **${profile.gamertag}** for Realm access.`)],
            flags: ComponentsV2Flags
        })
    } catch (error) {
        logger.error(`Link failed for ${interaction.user.id}: ${error.message}`)

        await interaction.editReply({
            components: [errorContainer('Link did not finish', 'The account could not be linked. Please try /account-link again.')],
            flags: ComponentsV2Flags
        })
    }
}

async function unlink(interaction) {
    await interaction.deferReply({ flags: MessageFlags.Ephemeral })

    const account = await getAccountByDiscordId(interaction.user.id)
    if (!account) {
        await interaction.editReply({
            components: [errorContainer('Nothing to remove', 'No Microsoft account is linked to your Discord account.')],
            flags: ComponentsV2Flags
        })
        return
    }

    disconnectAllForUser(interaction.user.id)

    await unlinkAccount(interaction.user.id)

    try {
        await clearAuthCacheForUser(interaction.user.id)
    } catch (error) {
        logger.warn(`Failed to clear auth cache for ${interaction.user.id}: ${error.message}`)
    }

    await interaction.editReply({
        components: [successContainer('Account disconnected', `**${account.gamertag}** is no longer linked to your Discord account.`)],
        flags: ComponentsV2Flags
    })
}

module.exports = {
    link,
    unlink,

    data: new SlashCommandBuilder()
        .setName('account-link')
        .setDescription('Connect Microsoft so the bot can use your Realms')
        .setIntegrationTypes([ApplicationIntegrationType.GuildInstall, ApplicationIntegrationType.UserInstall])
        .setContexts([InteractionContextType.Guild, InteractionContextType.BotDM, InteractionContextType.PrivateChannel]),

    async execute(interaction) {
        return link(interaction)
    }
}