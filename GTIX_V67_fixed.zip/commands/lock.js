'use strict'

const { SlashCommandBuilder, ApplicationIntegrationType, InteractionContextType } = require('discord.js')
const { errorContainer, successContainer, ComponentsV2Flags } = require('../stuff/utils/containers')
const { isLockOwner, toggleCommandLock } = require('../stuff/utils/commandLock')

const COMMAND_LABELS = {
    impact: 'impact',
    bedleak: 'bedleak',
    connect: 'connect',
    players: 'players',
    'realm-list': 'realm-list',
    tp: 'tp'
}

module.exports = {
    data: new SlashCommandBuilder()
        .setName('seal')
        .setDescription('Turn a command on or off for users')
        .setIntegrationTypes([ApplicationIntegrationType.GuildInstall])
        .setContexts([InteractionContextType.Guild])
        .addStringOption((option) => option
            .setName('command')
            .setDescription('Pick the command to pause or reopen')
            .setRequired(true)
            .addChoices(
                { name: 'impact', value: 'impact' },
                { name: 'bedleak', value: 'bedleak' },
                { name: 'connect', value: 'connect' },
                { name: 'players', value: 'players' },
                { name: 'realm-list', value: 'realm-list' },
                { name: 'tp', value: 'tp' }
            )),

    async execute(interaction) {
        if (!isLockOwner(interaction.user.id)) {
            await interaction.reply({
                components: [errorContainer('Owner only', 'Only the bot owner can change command access.')],
                flags: ComponentsV2Flags | 64
            })
            return
        }

        const commandName = interaction.options.getString('command')
        const locked = toggleCommandLock(commandName)
        const commandLabel = COMMAND_LABELS[commandName] || commandName
        await interaction.reply({
            components: [successContainer(
                locked ? `/${commandLabel} is paused` : `/${commandLabel} is open`,
                locked
                    ? `Users cannot run /${commandLabel} now. Use /seal and pick it again to reopen it.`
                    : `Users can run /${commandLabel} again.`
            )],
            flags: ComponentsV2Flags
        })
    }
}