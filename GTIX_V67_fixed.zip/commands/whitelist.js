'use strict'

const {
    SlashCommandBuilder,
    ApplicationIntegrationType,
    InteractionContextType
} = require('discord.js')
const { XboxAccount } = require('../stuff/api/xbox/xbox')
const { RealmAPI } = require('../stuff/api/realm/realm')
const { getAccountByDiscordId } = require('../database/models/account')
const {
    addWhitelistedRealmId,
    getWhitelistedEntries,
    updateWhitelistedRealmMetadata,
    refreshWhitelistCache
} = require('../database/models/whitelist')
const { disconnectAllForRealm } = require('../stuff/bedrockx')
const { isValidRealmCode, isValidRealmId } = require('../stuff/utils/validation')
const { successContainer, errorContainer, infoContainer, loadingContainer, ComponentsV2Flags } = require('../stuff/utils/containers')
const logger = require('../stuff/utils/logger')

const WHITELIST_MANAGER_USER_ID = '1454741598486401208'

async function respond(interaction, payload) {
    try {
        if (interaction.deferred || interaction.replied) {
            return await interaction.editReply(payload)
        }

        return await interaction.reply(payload)
    } catch (error) {
        logger.error(`Whitelist response failed: ${error.message}`)

        try {
            return await interaction.followUp({
                ...payload,
                flags: (payload.flags || 0) | 64
            })
        } catch (followUpError) {
            logger.error(`Whitelist follow-up response failed: ${followUpError.message}`)
            return null
        }
    }
}

async function resolveRealm(value, interaction, onAuthRequired) {
    if (isValidRealmId(value)) return { id: value }

    const linkedAccount = await getAccountByDiscordId(interaction.user.id)
    if (!linkedAccount) {
        throw new Error('Use /account-link first before entering a Realm code.')
    }

    let authPromptSent = false
    const account = new XboxAccount(interaction.user.id, async (data) => {
        if (authPromptSent) return
        authPromptSent = true

        await (onAuthRequired || respond)(interaction, {
                components: [loadingContainer(
                'Sign-in needed',
                `Open Microsoft, then enter code **${data.user_code}**.`,
                {
                    label: 'Open sign-in page',
                    url: `https://www.microsoft.com/link?otc=${encodeURIComponent(data.user_code)}`
                }
            )],
            flags: ComponentsV2Flags
        })
    })

    const realmApi = new RealmAPI(account)
    await realmApi.init()
    const realm = await realmApi.getRealmByCode(value)

    if (!realm?.id) throw new Error('No Realm was found for that Realm code.')
    return {
        id: String(realm.id),
        code: value,
        name: realm.name
    }
}

async function fetchWhitelistedRealmDetails(interaction, entries) {
    const linkedAccount = await getAccountByDiscordId(interaction.user.id)
    if (!linkedAccount) return entries

    let authPromptSent = false
    const account = new XboxAccount(interaction.user.id, async (data) => {
        if (authPromptSent) return
        authPromptSent = true

        await respond(interaction, {
                components: [loadingContainer(
                'Sign-in needed',
                `Open Microsoft, then enter code **${data.user_code}**.`,
                {
                    label: 'Open sign-in page',
                    url: `https://www.microsoft.com/link?otc=${encodeURIComponent(data.user_code)}`
                }
            )],
            flags: ComponentsV2Flags
        })
    })

    const realmApi = new RealmAPI(account)
    await realmApi.init()

    return Promise.all(entries.map(async (entry) => {
        try {
            const [realm, inviteCode] = await Promise.all([
                realmApi.getRealmById(entry.realmId),
                realmApi.getRealmInviteCode(entry.realmId).catch((error) => {
                    logger.error(`Failed to fetch invite code for Realm ${entry.realmId}: ${error.message}`)
                    return null
                })
            ])
            const name = realm?.name || entry.realmName || 'Unknown Realm'
            const code = inviteCode
                || realm?.inviteCode
                || realm?.realmInviteCode
                || realm?.code
                || realm?.realmCode
                || entry.realmCode
                || 'Unavailable'

            if (name !== entry.realmName || code !== entry.realmCode) {
                updateWhitelistedRealmMetadata(entry.realmId, { name, code })
            }

            return { ...entry, name, code }
        } catch (error) {
            logger.error(`Failed to fetch whitelisted Realm ${entry.realmId}: ${error.message}`)
            return {
                ...entry,
                name: entry.realmName || 'Unknown Realm',
                code: entry.realmCode || 'Unavailable'
            }
        }
    }))
}

async function rejectUnauthorizedUser(interaction) {
    if (interaction.inGuild() && interaction.user.id === WHITELIST_MANAGER_USER_ID) return false

    await respond(interaction, {
        components: [errorContainer('Not authorized', 'Only the configured whitelist manager can use this command.')],
        flags: ComponentsV2Flags | 64
    })
    return true
}

module.exports = {
    data: new SlashCommandBuilder()
        .setName('whitelist')
        .setDescription('Block every bot action on selected Realms')
        .setIntegrationTypes([ApplicationIntegrationType.GuildInstall])
        .setContexts([InteractionContextType.Guild])
        .addSubcommand((subcommand) => subcommand
            .setName('add')
            .setDescription('Stop the bot from using a Realm')
            .addStringOption((option) => option
                .setName('realm_id')
                .setDescription('Realm code or Realm ID')
                .setRequired(true)))
        .addSubcommand((subcommand) => subcommand
            .setName('remove')
            .setDescription('Allow the bot to use a Realm again')
            .addStringOption((option) => option
                .setName('realm_id')
                .setDescription('Realm code or Realm ID')
                .setRequired(true)))
        .addSubcommand((subcommand) => subcommand
            .setName('list')
            .setDescription('List blocked Realms, names, and codes')),

    async execute(interaction) {
        if (await rejectUnauthorizedUser(interaction)) return

        const subcommand = interaction.options.getSubcommand()

        if (subcommand === 'list') {
            await interaction.deferReply()
            await refreshWhitelistCache()
            const entries = getWhitelistedEntries()
                .sort((left, right) => left.realmId.localeCompare(right.realmId))
            const details = await fetchWhitelistedRealmDetails(interaction, entries)

            await respond(interaction, {
                components: [details.length
                    ? infoContainer(
                        'Protected Realms',
                        details.map((realm, index) =>
                            `**${index + 1}. ${realm.name}**\nCode: \`${realm.code}\`\nID: \`${realm.realmId}\``
                        ).join('\n\n')
                    )
                    : infoContainer('Protected Realms', 'No Realms are blocked right now.')],
                flags: ComponentsV2Flags
            })
            return
        }

        const realmValue = interaction.options.getString('realm_id')?.trim()
        if (!realmValue || (!isValidRealmId(realmValue) && !isValidRealmCode(realmValue))) {
            await interaction.reply({
                components: [errorContainer('Realm value is not valid', 'Enter a numeric Realm ID or a valid Realm code.')],
                flags: ComponentsV2Flags | 64
            })
            return
        }

        if (subcommand === 'remove') {
            await interaction.deferReply()
            try {
                const realm = await resolveRealm(realmValue, interaction)
                const { removeWhitelistedRealmId } = require('../database/models/whitelist')
                const removed = await removeWhitelistedRealmId(realm.id)

                await respond(interaction, {
                    components: [successContainer(
                        removed ? 'Realm protection removed' : 'Realm was not protected',
                        removed
                            ? `The bot can use Realm \`${realm.id}\` again.`
                            : `Realm \`${realm.id}\` was not blocked.`
                    )],
                    flags: ComponentsV2Flags
                })
            } catch (error) {
                await respond(interaction, {
                    components: [errorContainer('Could not change protection', error.message)],
                    flags: ComponentsV2Flags
                })
            }
            return
        }

        await interaction.deferReply()
        try {
            const realm = await resolveRealm(realmValue, interaction)
            const added = await addWhitelistedRealmId(realm.id)
            if (realm.name || realm.code) {
                updateWhitelistedRealmMetadata(realm.id, {
                    name: realm.name,
                    code: realm.code
                })
            }
            const disconnected = added ? disconnectAllForRealm(realm.id) : 0

            await respond(interaction, {
                components: [successContainer(
                    added ? 'Realm is now protected' : 'Realm was already protected',
                    added
                        ? `The bot will not use Realm \`${realm.id}\`.${disconnected
                            ? ` Closed ${disconnected} active bot connection${disconnected === 1 ? '' : 's'}.`
                            : ''}`
                        : `Realm \`${realm.id}\` is already blocked.`
                )],
                flags: ComponentsV2Flags
            })
        } catch (error) {
            await respond(interaction, {
                components: [errorContainer('Could not change protection', error.message)],
                flags: ComponentsV2Flags
            })
        }
    }
}