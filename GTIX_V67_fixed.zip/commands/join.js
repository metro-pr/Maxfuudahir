'use strict'

const { SlashCommandBuilder, ApplicationIntegrationType, InteractionContextType } = require('discord.js')
const { XboxAccount } = require('../stuff/api/xbox/xbox')
const { RealmAPI, assertRealmJoinable } = require('../stuff/api/realm/realm')
const { getAccountByDiscordId } = require('../database/models/account')
const { connectToRealm, disconnectFromRealm, hasActiveConnection } = require('../stuff/bedrockx/index')
const { registerRelay, getRelay } = require('../stuff/bedrockx/chatRelay')
const { isValidRealmCode, isValidRealmId } = require('../stuff/utils/validation')
const { blockIfWhitelisted } = require('../stuff/utils/whitelistGuard')
const { successContainer, errorContainer, loadingContainer, plainContainer, ComponentsV2Flags } = require('../stuff/utils/containers')
const { describeDisconnect } = require('../stuff/utils/disconnectReasons')
const logger = require('../stuff/utils/logger')

function normalizeConnection(raw) {
    if (raw.networkProtocol === 'DEFAULT') {
        const [ip, port] = raw.address.split(':')
        return { transport: 'DEFAULT', ip, port: Number(port) }
    }

    if (raw.networkProtocol === 'NETHERNET' || raw.networkProtocol === 'NETHERNET_JSONRPC') {
        return { transport: raw.networkProtocol, networkId: raw.address }
    }

    throw new Error(`Unrecognized realm connection response (networkProtocol: ${raw.networkProtocol})`)
}

function attachRelayLogging(client, dmChannel, realmName) {
    const send = (content) => {
        dmChannel.send({ components: [plainContainer(content)], flags: ComponentsV2Flags }).catch((error) => {
            logger.error(`[relay] Failed to send DM log: ${error.message}`)
        })
    }

    client.on('realm_chat', ({ player, message }) => {
        send(`${player || 'Realm player'} ${message}`.trim())
    })

    client.on('chat_sent', ({ source_name, message }) => {
        logger.info(`[relay] Realm chat packet sent as ${source_name || 'unknown player'}: ${message}`)
    })

    client.on('realm_join', ({ player }) => {
        send(`**${player}** joined ${realmName}`)
    })

    client.on('realm_leave', ({ player }) => {
        send(`**${player}** left ${realmName}`)
    })

    client.on('realm_death', ({ message }) => {
        send(message)
    })
}

module.exports = {
    data: new SlashCommandBuilder()
        .setName('connect')
        .setDescription('Open a Realm chat link in your DMs')
        .setIntegrationTypes([ApplicationIntegrationType.GuildInstall, ApplicationIntegrationType.UserInstall])
        .setContexts([InteractionContextType.Guild, InteractionContextType.BotDM, InteractionContextType.PrivateChannel])
        .addStringOption((option) => option
            .setName('code')
            .setDescription('Realm code or Realm ID')
            .setRequired(true)),

    async execute(interaction) {
        await interaction.deferReply()

        const destination = interaction.options.getString('code').trim()

        const isId = isValidRealmId(destination)
        const isCode = isValidRealmCode(destination)

        if (isId && await blockIfWhitelisted(interaction, destination)) return

        if (!isId && !isCode) {
            await interaction.editReply({ components: [errorContainer('Realm input is not valid', 'Enter a valid Realm code or a numeric Realm ID.')], flags: ComponentsV2Flags })
            return
        }

        const linkedAccount = await getAccountByDiscordId(interaction.user.id)
        if (!linkedAccount) {
            await interaction.editReply({ components: [errorContainer('Microsoft account needed', 'Run /account-link first so I can open the Realm.')], flags: ComponentsV2Flags })
            return
        }

        if (getRelay(interaction.user.id)) {
            await interaction.editReply({ components: [errorContainer('A relay is already open', 'Use /abort to close the current Realm connection first.')], flags: ComponentsV2Flags })
            return
        }

        if (isId && hasActiveConnection(interaction.user.id, destination)) {
            await interaction.editReply({ components: [errorContainer('This Realm is already open', 'Use /abort before opening another connection to it.')], flags: ComponentsV2Flags })
            return
        }

        await interaction.editReply({ components: [loadingContainer('Making the chat link', 'Joining the Realm and preparing your private chat…')], flags: ComponentsV2Flags })

        const account = new XboxAccount(interaction.user.id)
        let realmId

        try {
            const realmApi = new RealmAPI(account)
            await realmApi.init()

            const realm = isId
                ? await realmApi.getRealmById(destination)
                : await realmApi.getRealmByCode(destination)

            if (!realm) {
                await interaction.editReply({ components: [errorContainer('Realm not found', isId ? 'No Realm matches that ID.' : 'No Realm matches that code.')], flags: ComponentsV2Flags })
                return
            }

            if (await blockIfWhitelisted(interaction, realm.id)) return

            assertRealmJoinable(realm)

            realmId = String(realm.id)

            if (!isId && hasActiveConnection(interaction.user.id, realmId)) {
                await interaction.editReply({ components: [errorContainer('This Realm is already open', 'Use /abort before opening another connection to it.')], flags: ComponentsV2Flags })
                return
            }

            let dmChannel
            try {
                dmChannel = await interaction.user.createDM()
                await dmChannel.send({ components: [loadingContainer('Preparing your Realm chat', `Setting up messages for **${realm.name}**.`)], flags: ComponentsV2Flags })
            } catch (error) {
                await interaction.editReply({ components: [errorContainer('I cannot send DMs', "Open your Discord DMs, then run /connect again.")], flags: ComponentsV2Flags })
                return
            }

            const rawConnection = await realmApi.getConnectionInfo(realm.id)
            const connection = normalizeConnection(rawConnection)
            const deviceProfile = account.getDeviceProfile()
            const gamertag = await account.fetchGamertag().catch(() => undefined)

            const client = await connectToRealm(interaction.user.id, realmId, account.authflow, connection, deviceProfile)

            client.username = gamertag || linkedAccount.gamertag || interaction.user.username
            client.profile = { xuid: account.xuid }

            registerRelay(interaction.user.id, realmId, client, dmChannel)
            attachRelayLogging(client, dmChannel, realm.name)

            client.on('kick', (data) => {
                const reasonText = describeDisconnect(data)
                logger.info(`[/connect] Connection for realm ${realmId} ended: ${reasonText}`)
                dmChannel.send({ components: [errorContainer('Disconnected', reasonText)], flags: ComponentsV2Flags }).catch(() => {})
            })

            await interaction.editReply({ components: [successContainer('Realm chat is ready', `The chat link for **${realm.name}** is open. Check your DMs.`)], flags: ComponentsV2Flags })
            await dmChannel.send({
                components: [successContainer(
                    'You are connected',
                    `Messages sent here go to **${realm.name}** as Realm chat.\nPlayer joins, leaves, and deaths will appear here too.\nUse \`/abort\` to close the link.`
                )],
                flags: ComponentsV2Flags
            })
        } catch (error) {
            logger.error(`[/connect] Failed for ${interaction.user.id}: ${error.message}`)

            if (realmId) disconnectFromRealm(interaction.user.id, realmId, 'Join failed')

            const timedOut = /timed out/i.test(error.message)
            const title = timedOut ? 'The Realm took too long' : 'Chat link failed'
            const reasonText = error.message && error.message.trim().length > 0
                ? error.message
                : 'The Realm closed the connection and did not give a reason.'

            await interaction.editReply({ components: [errorContainer(title, reasonText)], flags: ComponentsV2Flags })
        }
    }
}
