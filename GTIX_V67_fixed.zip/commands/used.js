'use strict'

const {
    ChannelType,
    MessageFlags,
    PermissionsBitField,
    SlashCommandBuilder
} = require('discord.js')
const { errorContainer, successContainer, ComponentsV2Flags } = require('../stuff/utils/containers')
const { isLockOwner } = require('../stuff/utils/commandLock')
const { setSelectedChannelId } = require('../stuff/utils/usageSettings')

const requiredPermissions = [
    PermissionsBitField.Flags.ViewChannel,
    PermissionsBitField.Flags.SendMessages,
    PermissionsBitField.Flags.EmbedLinks,
    PermissionsBitField.Flags.AttachFiles
]

module.exports = {
    data: new SlashCommandBuilder()
        .setName('used')
        .setDescription('Choose where GTIX privately records command usage')
        .addChannelOption((option) => option
            .setName('channel')
            .setDescription('The channel where usage records should be posted')
            .addChannelTypes(ChannelType.GuildText, ChannelType.GuildAnnouncement)
            .setRequired(true)),

    async execute(interaction) {
        if (!isLockOwner(interaction.user.id)) {
            await interaction.reply({
                components: [errorContainer('Owner only', 'Only the bot owner can use /used.')],
                flags: MessageFlags.Ephemeral | ComponentsV2Flags
            })
            return
        }

        if (!interaction.inGuild()) {
            await interaction.reply({
                components: [errorContainer('Server channel required', 'Run /used inside a server and choose a text channel.')],
                flags: MessageFlags.Ephemeral | ComponentsV2Flags
            })
            return
        }

        const channel = interaction.options.getChannel('channel', true)
        const permissions = channel.permissionsFor(interaction.client.user)
        const missingPermission = requiredPermissions.find((permission) => !permissions?.has(permission))

        if (missingPermission) {
            await interaction.reply({
                components: [errorContainer(
                    'I cannot use that channel',
                    'Give GTIX View Channel, Send Messages, Embed Links, and Attach Files permissions there, then run /used again.'
                )],
                flags: MessageFlags.Ephemeral | ComponentsV2Flags
            })
            return
        }

        setSelectedChannelId(channel.id)

        await interaction.reply({
            components: [successContainer(
                'Usage logging enabled',
                `Future command usage will be posted in ${channel}. Only the bot owner can change this setting.`
            )],
            flags: MessageFlags.Ephemeral | ComponentsV2Flags
        })
    }
}