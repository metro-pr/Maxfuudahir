const { SlashCommandBuilder, ApplicationIntegrationType, InteractionContextType } = require('discord.js')
const { unlink } = require('./account')

module.exports = {
    data: new SlashCommandBuilder()
        .setName('account-unlink')
        .setDescription('Disconnect your Microsoft account from this bot')
        .setIntegrationTypes([ApplicationIntegrationType.GuildInstall, ApplicationIntegrationType.UserInstall])
        .setContexts([InteractionContextType.Guild, InteractionContextType.BotDM, InteractionContextType.PrivateChannel]),

    async execute(interaction) {
        return unlink(interaction)
    }
}