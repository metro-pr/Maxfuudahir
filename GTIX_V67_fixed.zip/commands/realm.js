const { SlashCommandBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ComponentType, ApplicationIntegrationType, InteractionContextType } = require('discord.js')
const { XboxAccount } = require('../stuff/api/xbox/xbox')
const { RealmAPI } = require('../stuff/api/realm/realm')
const { getAccountByDiscordId } = require('../database/models/account')
const { isValidRealmCode, isValidRealmId } = require('../stuff/utils/validation')
const { blockIfWhitelisted } = require('../stuff/utils/whitelistGuard')
const { successContainer, errorContainer, infoContainer, loadingContainer, ComponentsV2Flags } = require('../stuff/utils/containers')
const logger = require('../stuff/utils/logger')

const REALMS_PER_PAGE = 5
const PAGINATION_TIMEOUT_MS = 5 * 60_000

function microsoftLinkUrl(code) {
    return `https://www.microsoft.com/link?otc=${encodeURIComponent(code)}`
}

async function players(interaction) {
    await interaction.deferReply()

    const destination = interaction.options.getString('code').trim()

    const isId = isValidRealmId(destination)
    const isCode = isValidRealmCode(destination)

    if (isId && await blockIfWhitelisted(interaction, destination)) return

    if (!isId && !isCode) {
            await interaction.editReply({ components: [errorContainer('Realm input is not valid', 'Enter a valid Realm code or a numeric Realm ID.')], flags: ComponentsV2Flags })
        return
    }

    const linkedAccount = await getAccountByDiscordId(interaction.user.id)
    if (!linkedAccount) {
        await interaction.editReply({ components: [errorContainer('Microsoft account needed', 'Run /account-link first so I can read your Realm.')], flags: ComponentsV2Flags })
        return
    }

    await interaction.editReply({
        components: [loadingContainer('Checking who is online', 'Reading the current player list from the Realm…')],
        flags: ComponentsV2Flags
    })

    let authPromptSent = false
    const account = new XboxAccount(interaction.user.id, async (data) => {
        if (authPromptSent) return
        authPromptSent = true

        await interaction.editReply({
            components: [infoContainer(
                'Sign-in needed',
                `Open Microsoft, then enter code **${data.user_code}**.`,
                { label: 'Open sign-in page', url: microsoftLinkUrl(data.user_code) }
            )],
            flags: ComponentsV2Flags
        })
    })

    try {
        const realmApi = new RealmAPI(account)
        await realmApi.init()

        const realm = isId
            ? await realmApi.getRealmById(destination)
            : await realmApi.getRealmByCode(destination)

        if (!realm) {
                await interaction.editReply({ components: [errorContainer('Realm not found', isId ? 'No Realm matches that ID.' : 'No Realm matches that code.')], flags: ComponentsV2Flags })
            return
        }

        if (await blockIfWhitelisted(interaction, realm.id)) return

        const invitedPlayers = Array.isArray(realm.players) ? realm.players : []
        const onlinePlayers = invitedPlayers.filter((player) => player.online)
        const maxPlayers = realm.maxPlayers ?? onlinePlayers.length
        const onlineXuids = onlinePlayers.map((player) => player.uuid)

        const [gamertagsByXuid, devicesByXuid] = onlineXuids.length
            ? await Promise.all([
                account.fetchGamertagsByXuids(onlineXuids),
                account.fetchPresenceByXuids(onlineXuids)
            ])
            : [new Map(), new Map()]

        const list = onlineXuids.length
            ? onlineXuids
                .map((xuid) => {
                    const gamertag = gamertagsByXuid.get(xuid)
                    if (!gamertag) return null
                    return `• ${gamertag} | ${devicesByXuid.get(xuid) || 'Unknown'}`
                })
                .filter(Boolean)
                .join('\n')
            : 'No players are currently online.'

        await interaction.editReply({
            components: [successContainer('Players online now', `**${realm.name}** has ${onlinePlayers.length} of ${maxPlayers} player slots in use.\n\n${list}`)],
            flags: ComponentsV2Flags
        })
    } catch (error) {
        logger.error(`Realm player list failed for ${interaction.user.id}: ${error.message}`)

        const reasonText = error.message && error.message.trim().length > 0
            ? error.message
            : 'I could not read the player list. Please try again.'

        await interaction.editReply({ components: [errorContainer('Player list unavailable', reasonText)], flags: ComponentsV2Flags })
    }
}

function buildRealmListPage(realms, page, totalPages) {
    const start = page * REALMS_PER_PAGE
    const pageRealms = realms.slice(start, start + REALMS_PER_PAGE)

    const list = pageRealms
        .map((realm) => `**${realm.name}**\nID: \`${realm.id}\``)
        .join('\n\n')

    const description = `${list}\n\n-# Page ${page + 1} of ${totalPages}`

    const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
            .setCustomId('realmlist_prev')
            .setLabel('Back')
            .setStyle(ButtonStyle.Secondary)
            .setDisabled(page === 0),
        new ButtonBuilder()
            .setCustomId('realmlist_next')
            .setLabel('Next')
            .setStyle(ButtonStyle.Secondary)
            .setDisabled(page >= totalPages - 1)
    )

    return { container: successContainer('Realms you can use', description), row }
}

async function list(interaction) {
    await interaction.deferReply()

    const linkedAccount = await getAccountByDiscordId(interaction.user.id)
    if (!linkedAccount) {
        await interaction.editReply({ components: [errorContainer('Microsoft account needed', 'Run /account-link first so I can read your Realms.')], flags: ComponentsV2Flags })
        return
    }

    await interaction.editReply({
        components: [loadingContainer('Finding your Realms', 'Checking the Realms linked to your Microsoft account…')],
        flags: ComponentsV2Flags
    })

    const account = new XboxAccount(interaction.user.id)

    let realms
    try {
        const realmApi = new RealmAPI(account)
        await realmApi.init()

        realms = await realmApi.getRealms()
    } catch (error) {
        logger.error(`Realm list failed for ${interaction.user.id}: ${error.message}`)

        const reasonText = error.message && error.message.trim().length > 0
            ? error.message
            : 'I could not load your Realms. Please try again.'

        await interaction.editReply({ components: [errorContainer('Realm list unavailable', reasonText)], flags: ComponentsV2Flags })
        return
    }

    if (!realms.length) {
        await interaction.editReply({ components: [errorContainer('No usable Realms', "Your Microsoft account does not show any Realms you can open.")], flags: ComponentsV2Flags })
        return
    }

    const totalPages = Math.ceil(realms.length / REALMS_PER_PAGE)
    let page = 0

    const { container, row } = buildRealmListPage(realms, page, totalPages)
    const components = totalPages > 1 ? [container, row] : [container]

    await interaction.editReply({ components, flags: ComponentsV2Flags })

    if (totalPages <= 1) return

    const message = await interaction.fetchReply()

    const collector = message.createMessageComponentCollector({
        componentType: ComponentType.Button,
        time: PAGINATION_TIMEOUT_MS,
        filter: (buttonInteraction) => buttonInteraction.user.id === interaction.user.id
    })

    collector.on('collect', async (buttonInteraction) => {
        if (buttonInteraction.customId === 'realmlist_prev') page = Math.max(0, page - 1)
        if (buttonInteraction.customId === 'realmlist_next') page = Math.min(totalPages - 1, page + 1)

        const nextPage = buildRealmListPage(realms, page, totalPages)

        await buttonInteraction.update({ components: [nextPage.container, nextPage.row], flags: ComponentsV2Flags })
    })

    collector.on('end', async () => {
        const expiredRow = new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId('realmlist_prev').setLabel('Back').setStyle(ButtonStyle.Secondary).setDisabled(true),
            new ButtonBuilder().setCustomId('realmlist_next').setLabel('Next').setStyle(ButtonStyle.Secondary).setDisabled(true)
        )

        await interaction.editReply({
            components: [errorContainer('Command expired', 'This command has expired, run another one.'), expiredRow],
            flags: ComponentsV2Flags
        }).catch(() => {})
    })
}

module.exports = {
    data: new SlashCommandBuilder()
        .setName('realm-list')
        .setDescription('List the Realms available to you')
        .setIntegrationTypes([ApplicationIntegrationType.GuildInstall, ApplicationIntegrationType.UserInstall])
        .setContexts([InteractionContextType.Guild, InteractionContextType.BotDM, InteractionContextType.PrivateChannel]),

    async execute(interaction) {
        return list(interaction)
    },

    players
}