'use strict'

const { SlashCommandBuilder, ApplicationIntegrationType, InteractionContextType } = require('discord.js')
const { players } = require('./realm')

module.exports = {
    data: new SlashCommandBuilder()
        .setName('players')
        .setDescription('See who is online in a Realm')
        .setIntegrationTypes([ApplicationIntegrationType.GuildInstall, ApplicationIntegrationType.UserInstall])
        .setContexts([InteractionContextType.Guild, InteractionContextType.BotDM, InteractionContextType.PrivateChannel])
        .addStringOption((option) => option
            .setName('code')
            .setDescription('Realm code or Realm ID')
            .setRequired(true)),

    execute: players
}