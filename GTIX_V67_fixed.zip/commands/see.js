'use strict'

const {
    ChannelType,
    MessageFlags,
    PermissionsBitField,
    SlashCommandBuilder
} = require('discord.js')
const { errorContainer, plainContainer, ComponentsV2Flags } = require('../stuff/utils/containers')
const { isLockOwner } = require('../stuff/utils/commandLock')

function inviteChannels(guild, botUser) {
    return [...guild.channels.cache.values()]
        .filter((channel) => (
            channel.type === ChannelType.GuildText ||
            channel.type === ChannelType.GuildAnnouncement
        ))
        .filter((channel) => channel.permissionsFor(botUser)?.has(PermissionsBitField.Flags.CreateInstantInvite))
        .sort((a, b) => a.position - b.position)
}

async function createGuildInvite(guild, botUser) {
    try {
        await guild.channels.fetch()
    } catch {
        // Keep the guild in the private report even if its channel list cannot be refreshed.
    }

    const channel = inviteChannels(guild, botUser)[0]
    if (!channel) {
        return { guild, error: 'No channel where GTIX can create invites.' }
    }

    try {
        const invite = await channel.createInvite({
            maxAge: 0,
            maxUses: 0,
            unique: false,
            reason: 'Requested privately through /see'
        })
        return { guild, url: invite.url }
    } catch (error) {
        return { guild, error: error.message }
    }
}

module.exports = {
    data: new SlashCommandBuilder()
        .setName('see')
        .setDescription('Privately show invite links for every server GTIX is in'),

    async execute(interaction) {
        if (!isLockOwner(interaction.user.id)) {
            await interaction.reply({
                components: [errorContainer('Owner only', 'Only the bot owner can use /see.')],
                flags: MessageFlags.Ephemeral | ComponentsV2Flags
            })
            return
        }

        const client = interaction.client

        await interaction.deferReply({
            flags: MessageFlags.Ephemeral | ComponentsV2Flags
        })

        const guilds = [...client.guilds.cache.values()]
            .sort((a, b) => a.name.localeCompare(b.name))
        const results = await Promise.all(guilds.map((guild) => createGuildInvite(guild, client.user)))

        const lines = results.map(({ guild, url, error }) => (
            url
                ? `- **${guild.name}** — ${url}`
                : `- **${guild.name}** — unavailable (${error})`
        ))

        const description = lines.length > 0
            ? lines.join('\n')
            : 'GTIX is not currently in any servers.'

        await interaction.editReply({
            components: [plainContainer(`## All ${guilds.length} servers GTIX is in\n\n${description}\n\n-# This response is visible only to you.`)],
            flags: ComponentsV2Flags
        })
    }
}