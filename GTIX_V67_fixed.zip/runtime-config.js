'use strict'

const fs = require('fs')
const path = require('path')
const { ChatInputCommandInteraction, MessageFlags } = require('discord.js')
const COMPONENTS_V2_FLAG = MessageFlags.IsComponentsV2 ?? (1 << 15)

const configPath = require.resolve('./config.json')
const originalConfig = require(configPath)
const token = process.env.DISCORD_TOKEN || originalConfig.token

function deriveApplicationId(discordToken) {
    if (!discordToken) return ''

    try {
        const tokenPrefix = discordToken.split('.')[0]
        return Buffer.from(tokenPrefix, 'base64url').toString('utf8')
    } catch {
        return ''
    }
}

if (!token) {
    throw new Error('DISCORD_TOKEN is not configured')
}

const config = {
    ...originalConfig,
    token,
    applicationId: process.env.DISCORD_APPLICATION_ID
        || originalConfig.applicationId
        || deriveApplicationId(token),
    logChannelId: process.env.DISCORD_LOG_CHANNEL_ID || originalConfig.logChannelId || '',
    purgeChannelIds: process.env.DISCORD_PURGE_CHANNEL_IDS
        ? process.env.DISCORD_PURGE_CHANNEL_IDS.split(',').map((id) => id.trim()).filter(Boolean)
        : (originalConfig.purgeChannelIds || []).map((id) => String(id).trim()).filter(Boolean)
}

require.cache[configPath] = {
    id: configPath,
    filename: configPath,
    loaded: true,
    exports: config
}

const originalReadFileSync = fs.readFileSync
fs.readFileSync = function readFileSyncWithRuntimeConfig(filePath, ...args) {
    if (path.resolve(String(filePath)) === configPath) {
        const encoding = args[0]
        if (encoding === 'utf8' || (encoding && encoding.encoding === 'utf8')) {
            return JSON.stringify(config)
        }
    }

    return originalReadFileSync.call(this, filePath, ...args)
}

function withComponentsV2Flags(options) {
    const normalized = options ? { ...options } : {}
    normalized.flags = (normalized.flags || 0) | COMPONENTS_V2_FLAG
    return normalized
}

const originalDeferReply = ChatInputCommandInteraction.prototype.deferReply
const originalReply = ChatInputCommandInteraction.prototype.reply
const originalEditReply = ChatInputCommandInteraction.prototype.editReply

ChatInputCommandInteraction.prototype.deferReply = function deferReplyWithComponentsV2(options) {
    return originalDeferReply.call(this, withComponentsV2Flags(options))
}

ChatInputCommandInteraction.prototype.reply = function replyWithComponentsV2(options) {
    return originalReply.call(this, typeof options === 'string' ? options : withComponentsV2Flags(options))
}

ChatInputCommandInteraction.prototype.editReply = function editReplyWithComponentsV2(options) {
    return originalEditReply.call(this, withComponentsV2Flags(options))
}

const minecraftGameVersion = process.env.MINECRAFT_GAME_VERSION || '1.26.50'
const serializerPath = require.resolve('./stuff/bedrockx/src/transforms/serializer.js')
const serializer = require(serializerPath)
require.cache[serializerPath].exports = {
    ...serializer,
    GAME_VERSION: minecraftGameVersion
}

const realmApiPath = require.resolve('./stuff/api/realm/realm.js')
const realmApi = require(realmApiPath)
require.cache[realmApiPath].exports = {
    ...realmApi,
    gameVersion: minecraftGameVersion
}

const mongodbPath = require.resolve('./database/mongodb.js')
require.cache[mongodbPath] = {
    id: mongodbPath,
    filename: mongodbPath,
    loaded: true,
    exports: {
        async connectDatabase() {},
        async disconnectDatabase() {}
    }
}

const authCachePath = require.resolve('./database/models/authCache.js')
require.cache[authCachePath] = {
    id: authCachePath,
    filename: authCachePath,
    loaded: true,
    exports: require(path.join(__dirname, 'local-auth-cache.js'))
}