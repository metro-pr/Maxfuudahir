const { Events, ChannelType } = require('discord.js')
const { getRelay } = require('../stuff/bedrockx/chatRelay')
const { errorContainer, plainContainer, ComponentsV2Flags } = require('../stuff/utils/containers')
const logger = require('../stuff/utils/logger')

module.exports = {
    name: Events.MessageCreate,
    async execute(message) {
        if (message.author.bot) return
        if (message.channel.type !== ChannelType.DM) return

        const relay = getRelay(message.author.id)
        if (!relay) return

        const content = message.content?.trim()
        if (!content) return

        try {
            logger.info(`[chat relay] Received DM from ${message.author.id}; sending to Realm`)

            if (!relay.client?.runtime) {
                await message.channel.send({
                    components: [errorContainer('Realm chat is not ready', 'The Realm connection is still starting. Please wait a moment and try again.')],
                    flags: ComponentsV2Flags
                })
                return
            }

            relay.client.chat(content)
            logger.info(`[chat relay] Queued Realm chat from ${message.author.id} as ${relay.client.username || 'unknown player'}`)

            const minecraftName = relay.client.username || message.author.username
            await relay.dmChannel.send({
                components: [plainContainer(`${minecraftName} ${content}`)],
                flags: ComponentsV2Flags
            })
        } catch (error) {
            logger.error(`[chat relay] Failed to relay DM from ${message.author.id}: ${error.message}`)
            await message.channel.send({
                components: [errorContainer('Message was not sent', `I could not send that message to the Realm.\n${error.message}`)],
                flags: ComponentsV2Flags
            }).catch(() => {})
        }
    }
}
