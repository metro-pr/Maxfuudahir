const { Events, MessageFlags } = require('discord.js')
const { errorContainer, ComponentsV2Flags } = require('../stuff/utils/containers')
const { logCommandUsage } = require('../stuff/utils/commandLogger')
const { isCommandLocked } = require('../stuff/utils/commandLock')
const { isRealmWhitelistedFresh } = require('../database/models/whitelist')
const config = require('../config.json')
const logger = require('../stuff/utils/logger')

module.exports = {
    name: Events.InteractionCreate,
    async execute(interaction, client) {
        if (!interaction.isChatInputCommand()) return

        const command = client.commands.get(interaction.commandName)
        if (!command) return

        if (isCommandLocked(interaction.commandName)) {
            await interaction.reply({
                components: [errorContainer('Command paused', `The bot owner has paused /${interaction.commandName} for now.`)],
                flags: MessageFlags.Ephemeral | ComponentsV2Flags
            })
            return
        }

        if (interaction.commandName !== 'whitelist') {
            const destination = interaction.options.getString('destination')?.trim()
            if (destination && /^\d+$/.test(destination) && await isRealmWhitelistedFresh(destination)) {
                await interaction.reply({
                    components: [errorContainer('Realm is protected', 'The bot will not run tasks on this Realm.')],
                    flags: MessageFlags.Ephemeral | ComponentsV2Flags
                })
                return
            }
        }

        if (interaction.commandName !== 'used') {
            logCommandUsage(client, config, interaction)
        }

        try {
            await command.execute(interaction)
        } catch (error) {
            logger.error(`Command ${interaction.commandName} failed: ${error.message}`)

            const container = errorContainer('Command could not finish', 'The bot hit a problem while running this command.')

            try {
                if (interaction.deferred || interaction.replied) {
                    await interaction.editReply({ components: [container], flags: ComponentsV2Flags })
                } else {
                    await interaction.reply({ components: [container], flags: MessageFlags.Ephemeral | ComponentsV2Flags })
                }
            } catch (responseError) {
                logger.error(`Failed to send command error response: ${responseError.message}`)
            }
        }
    }
}
