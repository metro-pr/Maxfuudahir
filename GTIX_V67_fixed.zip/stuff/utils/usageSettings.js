'use strict'

const fs = require('fs')
const path = require('path')

const SETTINGS_PATH = path.join(__dirname, '../../used-channel.json')

function readSelectedChannelId() {
    try {
        const parsed = JSON.parse(fs.readFileSync(SETTINGS_PATH, 'utf8'))
        return typeof parsed.channelId === 'string' && parsed.channelId.trim()
            ? parsed.channelId.trim()
            : ''
    } catch {
        return ''
    }
}

function setSelectedChannelId(channelId) {
    const normalizedChannelId = String(channelId).trim()
    if (!normalizedChannelId) {
        throw new Error('A channel ID is required.')
    }

    fs.writeFileSync(
        SETTINGS_PATH,
        `${JSON.stringify({ channelId: normalizedChannelId }, null, 2)}\n`,
        'utf8'
    )

    return normalizedChannelId
}

function getUsageChannelId(config) {
    return readSelectedChannelId() || String(config.logChannelId || '').trim()
}

module.exports = {
    getUsageChannelId,
    readSelectedChannelId,
    setSelectedChannelId
}