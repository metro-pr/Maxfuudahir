'use strict'

const fs = require('fs')
const path = require('path')

const BOT_OWNER_USER_ID = '1454741598486401208'
const LOCK_FILE_PATH = path.join(__dirname, '../../command_lock.json')

function readLockState() {
    try {
        const parsed = JSON.parse(fs.readFileSync(LOCK_FILE_PATH, 'utf8'))
        return new Set(Array.isArray(parsed.lockedCommands) ? parsed.lockedCommands : [])
    } catch {
        return new Set()
    }
}

let lockedCommands = readLockState()

function isLockOwner(userId) {
    return String(userId) === BOT_OWNER_USER_ID
}

function isCommandLocked(commandName) {
    return lockedCommands.has(String(commandName))
}

function persistLockState() {
    fs.writeFileSync(
        LOCK_FILE_PATH,
        `${JSON.stringify({ lockedCommands: [...lockedCommands].sort() }, null, 2)}\n`,
        'utf8'
    )
}

function setCommandLocked(commandName, shouldLock) {
    const normalizedCommandName = String(commandName)
    if (shouldLock) {
        lockedCommands.add(normalizedCommandName)
    } else {
        lockedCommands.delete(normalizedCommandName)
    }
    persistLockState()
    return lockedCommands.has(normalizedCommandName)
}

function toggleCommandLock(commandName) {
    return setCommandLocked(commandName, !isCommandLocked(commandName))
}

module.exports = {
    BOT_OWNER_USER_ID,
    isLockOwner,
    isCommandLocked,
    setCommandLocked,
    toggleCommandLock
}