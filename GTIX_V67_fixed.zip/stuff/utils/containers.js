const { ContainerBuilder, TextDisplayBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, MessageFlags } = require('discord.js')

// GTIX we are gooners join us https://discord.gg/FY3mSDxRpV.
const brandColor = 0xf6c945
const successColor = 0x5cdb6b
const errorColor = 0xff4141
const loadingColor = 0x7545a8

function iconTitle(icon, title) {
    const value = String(title)
    return value.startsWith(icon) ? value : `${icon} ${value}`
}

function buildContainer(color, title, description, linkButton) {
    const body = String(description || '').trim() || 'No additional details.'

    const container = new ContainerBuilder()
        .setAccentColor(color)
        .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(`## ${title}\n\n${body}\n\n-# GTIX • Realm Operations`)
        )

    if (linkButton) {
        const row = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setLabel(linkButton.label)
                .setURL(linkButton.url)
                .setStyle(ButtonStyle.Link)
        )
        container.addActionRowComponents(row)
    }

    return container
}

function successContainer(title, description, linkButton) {
    return buildContainer(successColor, iconTitle('✅', title), description, linkButton)
}

function errorContainer(title, description) {
    return buildContainer(errorColor, iconTitle('🚫', title), description)
}

function infoContainer(title, description, linkButton) {
    return buildContainer(brandColor, iconTitle('✨', title), description, linkButton)
}

function loadingContainer(title, description, linkButton) {
    return buildContainer(
        loadingColor,
        iconTitle('🔄', title),
        `\`◐ ◓ ◑ ◒\`  ${description}`,
        linkButton
    )
}

function progressBar(current, total, width = 18) {
    const ratio = total > 0 ? Math.min(1, Math.max(0, current / total)) : 0
    const filled = Math.round(ratio * width)
    const empty = width - filled
    const percent = Math.round(ratio * 100)
    return `\`${'▓'.repeat(filled)}${'░'.repeat(empty)}\` **${percent}%**`
}

function progressContainer(title, description, current, total, linkButton) {
    return buildContainer(
        brandColor,
        iconTitle('⚡', title),
        `${progressBar(current, total)}\n\n${description}`,
        linkButton
    )
}

function plainContainer(content) {
    return new ContainerBuilder()
        .setAccentColor(brandColor)
        .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(content)
        )
}

module.exports = {
    successContainer,
    errorContainer,
    infoContainer,
    loadingContainer,
    progressContainer,
    plainContainer,
    ComponentsV2Flags: MessageFlags.IsComponentsV2
}