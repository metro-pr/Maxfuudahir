const { AttachmentBuilder, EmbedBuilder, ApplicationCommandOptionType } = require('discord.js')
const path = require('node:path')
const logger = require('./logger')
const { getUsageChannelId } = require('./usageSettings')

const logoPath = path.join(__dirname, '../../assets/gtix-logo.png')
const commandColors = {
    'account-link': 0x64a0e8,
    'account-unlink': 0x7545a8,
    impact: 0xff4141,
    abort: 0xf6c945,
    seal: 0x7545a8,
    bedleak: 0x5cdb6b,
    connect: 0x64a0e8,
    players: 0xf6c945,
    'realm-list': 0xf6c945,
    'seed-scan': 0x5cdb6b,
    tp: 0x7545a8,
    whitelist: 0xff4141
}

function flattenOptions(options = []) {
    let commandPath = []
    let args = []

    for (const option of options) {
        if (option.type === ApplicationCommandOptionType.SubcommandGroup || option.type === ApplicationCommandOptionType.Subcommand) {
            const nested = flattenOptions(option.options)
            commandPath = [option.name, ...nested.commandPath]
            args = [...args, ...nested.args]
        } else {
            args.push({ name: option.name, value: option.value })
        }
    }

    return { commandPath, args }
}

async function logCommandUsage(client, config, interaction) {
    const logChannelId = getUsageChannelId(config)
    if (!logChannelId) return

    try {
        const channel = client.channels.cache.get(logChannelId)
            || await client.channels.fetch(logChannelId).catch(() => null)

        if (!channel || !channel.isTextBased()) return

        const { commandPath, args } = flattenOptions(interaction.options?.data ?? [])
        const fullCommand = [interaction.commandName, ...commandPath].join(' ')
        const realmArgument = args.find((arg) => (
            ['code', 'destination', 'realm', 'realm_id', 'realmId'].includes(arg.name)
        ))
        const displayName = interaction.member?.displayName
            || interaction.user.globalName
            || interaction.user.username
        const logo = new AttachmentBuilder(logoPath, { name: 'gtix-logo.png' })

        const argsText = args.length
            ? args.map((arg) => `${arg.name}: ${arg.value}`).join('\n')
            : 'None'

        const commandColor = commandColors[interaction.commandName] ?? 0xf6c945
        const embed = new EmbedBuilder()
            .setColor(commandColor)
            .setAuthor({
                name: 'GTIX • Command activity',
                iconURL: 'attachment://gtix-logo.png'
            })
            .setTitle(`/${fullCommand}`)
            .setDescription('A GTIX command was used.')
            .setThumbnail(interaction.user.displayAvatarURL({ size: 256 }))
            .addFields(
                { name: 'User', value: displayName, inline: true },
                { name: 'User ID', value: interaction.user.id, inline: true },
                { name: 'Ping', value: `<@${interaction.user.id}>`, inline: true },
                { name: 'Command', value: `/${fullCommand}`, inline: false },
                { name: 'Realm used', value: realmArgument ? `\`${realmArgument.value}\`` : 'Not a Realm command', inline: false },
                { name: 'Arguments', value: `\`\`\`\n${argsText}\n\`\`\``, inline: false }
            )
            .setFooter({
                text: 'GTIX Realm Operations',
                iconURL: 'attachment://gtix-logo.png'
            })
            .setTimestamp()

        await channel.send({
            embeds: [embed],
            files: [logo]
        })
    } catch (error) {
        logger.error(`Failed to log command usage: ${error.message}`)
    }
}

module.exports = { logCommandUsage }