'use strict'

const WHITELISTED_REALM_IDS = [
  "12688747",
  "32939015"
]

module.exports = { WHITELISTED_REALM_IDS }
