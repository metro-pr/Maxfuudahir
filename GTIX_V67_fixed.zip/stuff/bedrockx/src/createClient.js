const { Client } = require('./client')

function createClient(options) {
    const client = new Client({ port: 19132, ...options, delayedInit: true })

    client.once('connect_allowed', () => connect(client))
    client.init().catch((error) => {
        queueMicrotask(() => {
            if (client.listenerCount('error') > 0) {
                client.emit('error', error instanceof Error ? error : new Error(String(error)))
            } else {
                console.warn(`Realm client setup failed: ${error?.message ?? error}`)
            }

            try {
                client.disconnect('Realm client setup failed')
            } catch {
                // The connection may already be closed.
            }
        })
    })

    return client
}

async function connect(client) {
    client.connect()

    client.once('resource_packs_info', () => {
        const completeResourcePackHandshake = () => {
            client.write('resource_pack_client_response', {
                response_status: 'completed',
                response_status_name: 'resourcepackstackfinished',
                resourcepackids: []
            })
        }

        client.once('resource_pack_stack', () => {
            completeResourcePackHandshake()
            client.write('request_chunk_radius', { chunk_radius: 16, max_radius: 8 })
        })

        completeResourcePackHandshake()
    })
}

module.exports = { createClient }