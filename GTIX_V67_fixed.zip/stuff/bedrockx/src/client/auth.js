const { Authflow } = require('prismarine-auth')

function getErrorMessage(error) {
  return error instanceof Error ? error.message : String(error)
}

function decodeTokenPayload(token) {
  const payload = token.split('.')[1]
  if (!payload) return {}

  try {
    return JSON.parse(Buffer.from(payload, 'base64url').toString('utf8'))
  } catch (error) {
    throw new Error(`Minecraft returned an invalid multiplayer session token: ${getErrorMessage(error)}`)
  }
}

async function authenticate(client, options) {
  try {
    options.authflow ??= new Authflow(options.username, options.profilesFolder, options, options.onMsaCode)

    const signedToken = await options.authflow.getMinecraftBedrockMultiplayerToken(
      client.clientX509,
      { version: client.options.version }
    )

    if (typeof signedToken !== 'string' || !signedToken) {
      throw new Error('Minecraft did not return a Bedrock multiplayer session token')
    }

    client.tokenData = decodeTokenPayload(signedToken)
    client.token = signedToken
    client.emit('session')
    return signedToken
  } catch (error) {
    const message = `Bedrock authentication failed: ${getErrorMessage(error)}`
    console.error(`[bedrockx] ${message}`)
    throw new Error(message, { cause: error })
  }
}

module.exports = { authenticate }