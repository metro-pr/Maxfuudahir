const { EventEmitter, once } = require('node:events')
const { WebSocket } = require('ws')
const { SignalStructure } = require('../nethernet/index')
const { v4fast: v4 } = require("uuid-1345")
const JSONBigInt = require('json-bigint')({ useNativeBigInt: true })

const MAX_RETRIES = 5
const INITIAL_CONNECT_ATTEMPTS = 2
const CREDENTIAL_TIMEOUT_MS = 10_000
const INITIAL_RETRY_DELAY_MS = 3_000

class NethernetJSONRPC extends EventEmitter {
    constructor(networkId, authflow, version, serverNetworkId) {
        super()
        this.networkId = networkId
        this.serverNetworkId = serverNetworkId
        this.authflow = authflow
        this.version = version
        this.ws = null
        this.credentials = []
        this.candidates = []
        this.signalCandidates = []

        this.pingInterval = null
        this.retryCount = 0
        this.destroyed = false
        this.lastLiveness = 0
        this.connectionId = null
        this.didSendCandidates = false
        this.connecting = false
    }

    async connect() {
        if (this.ws?.readyState === WebSocket.OPEN) throw new Error('Already connected signaling server');
        this.destroyed = false

        this.connecting = true
        let lastError

        try {
            for (let attempt = 1; attempt <= INITIAL_CONNECT_ATTEMPTS; attempt++) {
                try {
                    this.credentials = []
                    await this.init()
                    await this.waitForCredentials(CREDENTIAL_TIMEOUT_MS)
                    return
                } catch (error) {
                    lastError = error
                    await this.destroy(false).catch(() => {})

                    if (attempt < INITIAL_CONNECT_ATTEMPTS) {
                        const delay = INITIAL_RETRY_DELAY_MS * attempt
                        console.warn(`Minecraft signaling is busy; retrying in ${delay / 1000}s (${attempt}/${INITIAL_CONNECT_ATTEMPTS - 1})`)
                        this.destroyed = false
                        await new Promise((resolve) => setTimeout(resolve, delay))
                        if (this.destroyed) break
                    }
                }
            }
        } finally {
            this.connecting = false
        }

        throw new Error('Minecraft signaling is busy right now. Please wait a moment and try again.')
    }

    async waitForCredentials(timeoutMs) {
        if (this.credentials.length > 0) return
        if (!this.ws) throw new Error('The signaling connection closed before it was ready.')

        await new Promise((resolve, reject) => {
            const ws = this.ws
            const cleanup = () => {
                clearTimeout(timeout)
                this.removeListener('credentials', onCredentials)
                ws.removeListener('close', onClose)
                ws.removeListener('error', onError)
            }
            const onCredentials = () => {
                cleanup()
                resolve()
            }
            const onClose = (code, reason) => {
                cleanup()
                reject(new Error(`The signaling server closed the connection (${code}${reason ? `: ${reason}` : ''}).`))
            }
            const onError = (error) => {
                cleanup()
                reject(error instanceof Error ? error : new Error(String(error)))
            }
            const timeout = setTimeout(() => {
                cleanup()
                reject(new Error('Timed out waiting for signaling credentials'))
            }, timeoutMs)

            this.once('credentials', onCredentials)
            ws.once('close', onClose)
            ws.once('error', onError)
        })
    }

    async destroy(resume = false) {
        this.destroyed = !resume

        if (this.pingInterval) {
            clearInterval(this.pingInterval)
            this.pingInterval = null
        }

        const ws = this.ws
        this.ws = null

        if (ws) {
            ws.removeAllListeners("open")
            ws.removeAllListeners("close")
            ws.removeAllListeners("error")
            ws.removeAllListeners("message")

            if (ws.readyState === WebSocket.OPEN || ws.readyState === WebSocket.CONNECTING) {
                await new Promise((resolve) => {
                    const done = () => resolve()

                    ws.once("close", done)

                    try {
                        ws.close(1000, "Normal Closure")
                    } catch {
                        resolve()
                    }
                })
            }
        }

        if (resume) return this.reconnectWithBackoff()
    }

    async reconnectWithBackoff() {
        if (this.destroyed) return

        const delay = Math.min(15000 * Math.max(1, this.retryCount), 60000)
        await new Promise((r) => setTimeout(r, delay));

        if (this.destroyed) return

        try {
            await this.init();
        } catch (e) {
            console.error("Signal reconnect attempt failed, will retry:", e)
            this.reconnectWithBackoff().catch(() => {})
        }
    }

    async init() {
        const xbl = await this.authflow.getMinecraftBedrockServicesToken({ version: this.version })

        const address = `https://signal.franchise.minecraft-services.net/ws/v1.0/messaging/connect`;

        try {
            const ws = new WebSocket(address, { headers: { Authorization: xbl.mcToken, "session-id": v4(), "request-id": v4() } })
            this.ws = ws
            this.lastLiveness = Date.now()

            ws.on("open", () => this.onOpen())
            ws.on("close", (code, reason) => this.onClose(ws, code, reason.toString()))
            ws.on("error", (err) => this.onError(ws, err))
            ws.on("message", (data) => this.onMessage(data))

            if (!this.pingInterval) {
                this.pingInterval = setInterval(() => {
                    if (!this.ws || this.ws.readyState !== WebSocket.OPEN) return

                    this.safeSend(JSON.stringify({ params: {}, jsonrpc: "2.0", method: "System_Ping_v1_0", id: v4() }))

                    if (Date.now() - this.lastLiveness > 60000) {
                        try {
                            this.ws.terminate?.()
                        } catch { }
                    }
                }, 2000)
            }
        } catch (error) {
            console.warn(`Signaling socket could not be created: ${error?.message ?? error}`)
        }
    }

    onOpen() {
        this.retryCount = 0
        this.lastLiveness = Date.now()
        this.safeSend(JSON.stringify({
            params: {},
            jsonrpc: "2.0",
            method: "Signaling_TurnAuth_v1_0",
            id: v4()
        }))
    }

    onError(ws, err) {
        if (this.ws !== ws || this.destroyed) return

        console.warn(`Signaling socket error: ${err?.message ?? err}`)
    }

    async onClose(ws, code, reason) {
        if (this.ws !== ws) return

        if (this.ws === null && this.pingInterval) {
            clearInterval(this.pingInterval)
            this.pingInterval = null
        }

        if (this.destroyed) return
        if (this.connecting) return

        if (this.retryCount >= MAX_RETRIES) {
            console.warn(`Signal closed: ${code} ${reason} - maximum reconnect attempts reached; stopping reconnects.`)
            await this.destroy(false)
            return
        }

        this.retryCount++
        console.warn(`Signal closed: ${code} ${reason} - reconnecting (attempt ${this.retryCount}/${MAX_RETRIES})...`)
        try {
            await this.destroy(true)
        } catch (err) {
            console.error("Error while reconnecting signaling socket:", err)
            this.reconnectWithBackoff().catch((reconnectError) => {
                console.warn(`Signaling reconnect stopped: ${reconnectError?.message ?? reconnectError}`)
            })
        }
    }

    onMessage(res) {
        this.lastLiveness = Date.now()

        let message = null

        try {
            if (typeof res === "string") {
                message = JSON.parse(res)
            } else if (Buffer.isBuffer(res)) {
                message = JSON.parse(res.toString("utf8"))
            } else {
                return
            }
        } catch (error) {
            return
        }

        if (Array.isArray(message.result?.TurnAuthServers)) {
            this.credentials = parseTurnServers(JSON.stringify(message.result))
            this.emit("credentials", this.credentials)
        }

        switch (message.method) {
            case "System_Pong_v1_0":
                this.safeSend(JSON.stringify({ id: message.id, result: null, jsonrpc: "2.0" }))
                break
            case "Signaling_ReceiveMessage_v1_0":
                this.safeSend(JSON.stringify({ id: message.id, result: null, jsonrpc: "2.0" }))
                const params = Array.isArray(message.params)? message.params : message.params ? [message.params]: []
                for (const param of params) {
                    this.sendDeliveryNotification(param.From, param.Id)
                    let signalMessage = param.Message
                    try {
                        const parsed = JSON.parse(param.Message)

                        switch (parsed.method) {
                            case "Signaling_WebRtc_v1_0":
                                if (parsed.params?.message) signalMessage = parsed.params.message
                                break
                            case "Signaling_DeliveryNotification_V1_0":
                                continue
                        }
                    } catch (e) {
                        console.error(e)
                    }

                    if (signalMessage.includes("could not be delivered")) continue

                    let signal = SignalStructure.fromString(signalMessage)
                    signal.connectionId = BigInt(signal.connectionId)
                    signal.networkId = this.networkId
                    signal.serverNetworkId = param.From ?? this.serverNetworkId

                    if (signal.type === "CANDIDATEADD") {
                        signal.data += " network-cost 10";

                        if (!this.didSendCandidates) {
                            this.signalCandidates.push(signal);
                            return
                        }
                    }

                    if (
                        signal.type === "CONNECTRESPONSE" &&
                        signal.connectionId === this.connectionId &&
                        !this.didSendCandidates
                    ) {
                        for (const candidate of this.candidates) {
                            this.write(candidate)
                        }

                        for (const signalCandidate of this.signalCandidates) {
                            this.emit("signal", signalCandidate)
                        }

                        this.didSendCandidates = true
                    }

                    this.emit("signal", signal)
                }
                break
            default:
                break
        }
    }

    write(signal) {
        if (!this.ws || this.ws.readyState !== WebSocket.OPEN) return false

        let uuidv4 = v4()

        if (signal.type === "CANDIDATEADD" && !this.candidates.includes(signal)) {
            this.candidates.length === 0 ? signal.data += " network-cost 50" : signal.data += " network-cost 10"

            if (signal.data.includes("tcp") || signal.data.includes("::1") || signal.data.includes("127.0.0.1")) return;

            this.candidates.push(signal)
            return
        }

        if (signal.type === "CONNECTREQUEST") this.connectionId = signal.connectionId

        const message = JSONBigInt.stringify({
            params: {
                toPlayerId: String(signal.serverNetworkId ?? this.serverNetworkId),
                messageId: uuidv4,
                message: JSONBigInt.stringify({
                    params: {
                        netherNetId: String(signal.networkId),
                        message: signal.toString(),
                    },
                    jsonrpc: "2.0",
                    method: "Signaling_WebRtc_v1_0",
                })
            },
            jsonrpc: "2.0",
            method: "Signaling_SendClientMessage_v1_0",
            id: uuidv4
        })

        return this.safeSend(message)
    }

    sendDeliveryNotification(toPlayerId, messageId) {
        const uuidv4 = v4()
        const message = JSONBigInt.stringify({
            params: {
                toPlayerId,
                messageId: uuidv4,
                message: JSONBigInt.stringify({
                    params: {
                        messageId
                    },
                    jsonrpc: "2.0",
                    method: "Signaling_DeliveryNotification_V1_0"
                })
            },
            jsonrpc: "2.0",
            method: "Signaling_SendClientMessage_v1_0",
            id: uuidv4
        })

        return this.safeSend(message)
    }

    safeSend(message) {
        const ws = this.ws
        if (!ws || ws.readyState !== WebSocket.OPEN) return false

        try {
            ws.send(message)
            return true
        } catch (error) {
            console.warn(`Signaling message dropped: ${error?.message ?? error}`)
            return false
        }
    }
}

module.exports = { NethernetJSONRPC }

function parseTurnServers(dataString) {
    const iceServers = []
    const TurnAuthServers = JSON.parse(dataString)?.TurnAuthServers ?? []

    for (const server of TurnAuthServers) {
        const urls = server?.Urls ?? []
        const username = typeof server?.Username === "string" ? server.Username : undefined
        const credential = typeof server?.Password === "string" ? server.Password : (typeof server?.Credential === "string" ? server.Credential : undefined)

        for (const rawUrl of urls) {
            const parsedUrl = parseIceUrl(rawUrl)
            if (!parsedUrl) continue

            const urlCandidates = new Set([formatIceUrl(parsedUrl)])

            if (parsedUrl.isTurn) {
                if (parsedUrl.transport !== "tcp") urlCandidates.add(formatIceUrl({ ...parsedUrl, transport: "udp" }))
                if (parsedUrl.scheme !== "turns") urlCandidates.add(formatIceUrl({ ...parsedUrl, scheme: "turns", port: 5349, transport: "udp" }))
            }

            for (const url of urlCandidates) {
                parsedUrl.isTurn ? iceServers.push({ urls: url, username, credential }) : iceServers.push({ urls: url })
            }
        }
    }

    return iceServers
}

function parseIceUrl(url) {
    const match = url.trim().match(/^(?<scheme>stuns?|turns?)(?::\/\/|:)?(?<host>[^:?\s]+)(?::(?<port>\d+))?(?:\?(?<query>.*))?$/i)
    if (!match || !match.groups) return null

    const scheme = match.groups.scheme.toLowerCase()
    const hostname = match.groups.host
    const port = match.groups.port ? parseInt(match.groups.port, 10) : defaultPortForScheme(scheme)

    if (!hostname || Number.isNaN(port)) return null

    const isTurn = scheme.startsWith("turn")

    let transport
    if (scheme === "turns") transport = "tcp"

    if (isTurn) transport = match.groups.query?.split("&").find(param => param.startsWith("transport="))?.split("=")[1] ?? "udp"
    if (!transport) transport = "udp"

    return { scheme, hostname, port, transport, isTurn }
}

function formatIceUrl(parsed) {
    const protocol = parsed.scheme
    const base = `${protocol}:${parsed.hostname}:${parsed.port}`

    if (!parsed.isTurn) return base

    return `${base}?transport=${parsed.transport ?? "udp"}`
}

function defaultPortForScheme(scheme) {
    return scheme === "stuns" ? 3478 : 5349
}
