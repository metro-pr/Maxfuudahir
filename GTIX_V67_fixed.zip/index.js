require('./runtime-config')

const { Client, GatewayIntentBits, Partials } = require('discord.js')
const config = require('./config.json')

config.token = process.env.DISCORD_TOKEN || config.token
config.applicationId = process.env.DISCORD_APPLICATION_ID || config.applicationId
config.mongodbUri = process.env.MONGODB_URI || config.mongodbUri
config.logChannelId = process.env.LOG_CHANNEL_ID || config.logChannelId
const { syncWhitelist } = require('./database/models/whitelist')
const { watchWhitelistFile, loadWhitelistFile } = require('./stuff/utils/whitelistWatcher')
const { loadCommands } = require('./handlers/commandhandler')
const { loadEvents } = require('./handlers/eventhandler')
const { deployCommands } = require('./handlers/deployhandler')
const { disconnectAll } = require('./stuff/bedrockx/index')
const { startChannelPurger, stopChannelPurger } = require('./stuff/utils/channelPurger')
const logger = require('./stuff/utils/logger')
const fs = require('fs')
const path = require('path')
const http = require('http')

const configPath = path.join(__dirname, 'config.json')

function getPurgeChannelIds() {
    try {
        const raw = fs.readFileSync(configPath, 'utf8')
        const parsed = JSON.parse(raw)
        return Array.isArray(parsed.purgeChannelIds) ? parsed.purgeChannelIds : []
    } catch (err) {
        logger.error(`Failed to read purgeChannelIds from config.json: ${err.message}`)
        return []
    }
}

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.DirectMessages
    ],
    partials: [Partials.Channel, Partials.Message]
})

const healthPort = Number(process.env.PORT || 8080)
if (!Number.isInteger(healthPort) || healthPort <= 0) {
    throw new Error(`Invalid PORT value: "${process.env.PORT}"`)
}

const healthServer = http.createServer((request, response) => {
    if (request.url !== '/healthz' && request.url !== '/api/healthz') {
        response.writeHead(404, { 'content-type': 'application/json' })
        response.end(JSON.stringify({ status: 'not_found' }))
        return
    }

    response.writeHead(200, { 'content-type': 'application/json' })
    response.end(JSON.stringify({ status: 'ok', discordReady: client.isReady() }))
})

healthServer.listen(healthPort, () => {
    logger.info(`Health server listening on port ${healthPort}`)
})

async function main() {
    const whitelisted = await syncWhitelist(loadWhitelistFile())
    logger.info(`Synced ${whitelisted} whitelisted realm id(s) from JSON storage`)

    watchWhitelistFile(async (ids) => {
        const count = await syncWhitelist(ids)
        logger.info(`Whitelist file changed, synced ${count} realm id(s) to MongoDB`)
    })

    loadCommands(client)
    loadEvents(client)

    try {
        const count = await deployCommands(config)
        logger.info(`Deployed ${count} slash commands`)
    } catch (error) {
        logger.error(`Failed to deploy commands on startup: ${error.message}`)
    }

    await client.login(config.token)

    const guildIds = process.env.DISCORD_GUILD_ID
        ? [process.env.DISCORD_GUILD_ID]
        : [...client.guilds.cache.keys()]

    for (const guildId of guildIds) {
        try {
            await deployCommands(config, guildId)
            logger.info(`Registered slash commands instantly in guild ${guildId}`)
        } catch (error) {
            logger.warn(`Failed to register guild slash commands in ${guildId}: ${error.message}`)
        }
    }

    startChannelPurger(client, getPurgeChannelIds)
}

async function shutdown(signal) {
    logger.info(`Received ${signal}, shutting down`)

    stopChannelPurger()
    disconnectAll()
    healthServer.close()
    client.destroy()

    process.exit(0)
}

process.on('SIGINT', () => shutdown('SIGINT'))
process.on('SIGTERM', () => shutdown('SIGTERM'))

main().catch((error) => {
    logger.error(`Failed to start Zepher: ${error.message}`)
    process.exit(1)
})
