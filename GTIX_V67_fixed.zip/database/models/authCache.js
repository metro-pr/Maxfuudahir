'use strict'

module.exports = require('../../local-auth-cache')
