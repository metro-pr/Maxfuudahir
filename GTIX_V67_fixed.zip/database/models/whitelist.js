'use strict'

const fs = require('fs')
const path = require('path')
const logger = require('../../stuff/utils/logger')

const DATA_PATH = path.join(__dirname, '..', '..', 'whitelisted.json')
const SOURCE_PATH = path.join(__dirname, '..', '..', 'stuff', 'whitelist.js')

const cache = new Set()

function normalizeId(realmId) {
    return String(realmId ?? '').trim()
}

function loadFile() {
    try {
        if (!fs.existsSync(DATA_PATH)) {
            fs.writeFileSync(DATA_PATH, '[]', 'utf8')
            return []
        }

        const raw = fs.readFileSync(DATA_PATH, 'utf8')
        const parsed = JSON.parse(raw)
        return Array.isArray(parsed) ? parsed : []
    } catch (error) {
        logger.error(`Failed to read whitelisted.json: ${error.message}`)
        return []
    }
}

function saveFile(entries) {
    try {
        fs.writeFileSync(DATA_PATH, JSON.stringify(entries, null, 2), 'utf8')
    } catch (error) {
        logger.error(`Failed to write whitelisted.json: ${error.message}`)
    }
}

function saveWhitelistSource(realmIds) {
    const ids = [...new Set(realmIds.map(normalizeId).filter(Boolean))]
    const source = `'use strict'\n\nconst WHITELISTED_REALM_IDS = ${JSON.stringify(ids, null, 2)}\n\nmodule.exports = { WHITELISTED_REALM_IDS }\n`

    try {
        fs.writeFileSync(SOURCE_PATH, source, 'utf8')
    } catch (error) {
        logger.error(`Failed to write whitelist.js: ${error.message}`)
    }
}

async function syncWhitelist(realmIds) {
    const ids = [...new Set((realmIds || []).map(normalizeId).filter((id) => id.length > 0))]

    const existing = loadFile()
    const existingById = new Map(existing.map((entry) => [normalizeId(entry.realmId), entry]))

    const entries = ids.map((realmId) => existingById.get(realmId) || { realmId, addedAt: new Date().toISOString() })

    saveFile(entries)

    await refreshWhitelistCache()

    return ids.length
}

async function addWhitelistedRealmId(realmId) {
    const id = normalizeId(realmId)
    const entries = loadFile()
    const ids = [...new Set(entries.map((entry) => normalizeId(entry.realmId)).filter(Boolean))]

    if (!ids.includes(id)) ids.push(id)

    saveWhitelistSource(ids)
    await syncWhitelist(ids)
    return !entries.some((entry) => normalizeId(entry.realmId) === id)
}

async function removeWhitelistedRealmId(realmId) {
    const id = normalizeId(realmId)
    const entries = loadFile()
    const ids = entries
        .map((entry) => normalizeId(entry.realmId))
        .filter((entryId) => entryId && entryId !== id)

    saveWhitelistSource(ids)
    await syncWhitelist(ids)
    return ids.length !== entries.length
}

async function refreshWhitelistCache() {
    const entries = loadFile()

    cache.clear()
    for (const entry of entries) cache.add(normalizeId(entry.realmId))

    return cache.size
}

function isRealmWhitelisted(realmId) {
    return cache.has(normalizeId(realmId))
}

async function isRealmWhitelistedFresh(realmId) {
    const id = normalizeId(realmId)
    if (id.length === 0) return false
    if (cache.has(id)) return true

    const entries = loadFile()
    const found = entries.some((entry) => normalizeId(entry.realmId) === id)
    if (found) cache.add(id)

    return found
}

function getWhitelistedRealmIds() {
    return [...cache]
}

function getWhitelistedEntries() {
    return loadFile()
        .map((entry) => ({
            ...entry,
            realmId: normalizeId(entry.realmId)
        }))
        .filter((entry) => entry.realmId)
}

function updateWhitelistedRealmMetadata(realmId, metadata = {}) {
    const id = normalizeId(realmId)
    const entries = loadFile()
    const entry = entries.find((item) => normalizeId(item.realmId) === id)

    if (!entry) return false

    if (metadata.name) entry.realmName = String(metadata.name)
    if (metadata.code) entry.realmCode = String(metadata.code)

    saveFile(entries)
    return true
}

module.exports = {
    syncWhitelist,
    addWhitelistedRealmId,
    removeWhitelistedRealmId,
    refreshWhitelistCache,
    isRealmWhitelisted,
    isRealmWhitelistedFresh,
    getWhitelistedRealmIds,
    getWhitelistedEntries,
    updateWhitelistedRealmMetadata
}
