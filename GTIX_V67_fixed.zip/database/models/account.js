'use strict'

const fs = require('fs')
const path = require('path')
const logger = require('../../stuff/utils/logger')

const DATA_PATH = path.join(__dirname, '..', '..', 'linked_accounts.json')

function loadAccounts() {
    try {
        if (!fs.existsSync(DATA_PATH)) {
            fs.writeFileSync(DATA_PATH, '[]', 'utf8')
            return []
        }

        const raw = fs.readFileSync(DATA_PATH, 'utf8')
        const parsed = JSON.parse(raw)
        return Array.isArray(parsed) ? parsed : []
    } catch (error) {
        logger.error(`Failed to read linked_accounts.json: ${error.message}`)
        return []
    }
}

function saveAccounts(accounts) {
    try {
        fs.writeFileSync(DATA_PATH, JSON.stringify(accounts, null, 2), 'utf8')
    } catch (error) {
        logger.error(`Failed to write linked_accounts.json: ${error.message}`)
    }
}

async function getAccountByDiscordId(discordId) {
    const accounts = loadAccounts()
    return accounts.find((account) => account.discordId === discordId) || null
}

async function getAccountByXuid(xuid) {
    const accounts = loadAccounts()
    return accounts.find((account) => account.xuid === xuid) || null
}

async function linkAccount(discordId, xuid, gamertag) {
    const accounts = loadAccounts()
    const index = accounts.findIndex((account) => account.discordId === discordId)
    const record = { discordId, xuid, gamertag, linkedAt: new Date().toISOString() }

    if (index >= 0) accounts[index] = record
    else accounts.push(record)

    saveAccounts(accounts)
    return record
}

async function unlinkAccount(discordId) {
    const accounts = loadAccounts()
    const index = accounts.findIndex((account) => account.discordId === discordId)
    if (index === -1) return null

    const [removed] = accounts.splice(index, 1)
    saveAccounts(accounts)
    return removed
}

module.exports = { getAccountByDiscordId, getAccountByXuid, linkAccount, unlinkAccount }
